package fails;

public class CollectException extends Exception{

    public CollectException(String message) {
        super(message);
    }
}
