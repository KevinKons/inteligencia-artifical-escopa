package fails;

public class DropException extends Exception{

    public DropException(String message) {
        super(message);
    }
}
