package fails;

public class CardNotFounded extends Exception{

    public CardNotFounded(String message) {
        super(message);
    }
}
